# Readme
### Notes
- project was done in ubuntu
- event module is incomplete due to time restrictions
- not production quality, alpha version due to time restrictions
### Run and setup mongodb
Execute commands in terminal
- cd code-tradeledger
- ./drmongo.sh 
- ./insert-data.sh 
### Run spring boot application
Execute commands in terminal
- cd code-tradeledger/session-facade
- ./gradlew bootRun
### Call rest endpoint
use browser or postman, eq.
- http://localhost:6868/user
- http://localhost:6868/user/search?filter={"attribute": "user", "operator": "eq", "value": "user4@sample.io"}
