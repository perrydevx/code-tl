#!/usr/bin/env bash

echo "~~~~~~~~~~~~ running mongo db in docker container"

docker run --name mongo-tl -d -p 27777:27017 mongo

echo "~~~~~~~~~~~~ mongodb running at prot 27777"
