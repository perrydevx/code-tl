package com.perry.tradeledger.sessionfacade.controller;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.perry.tradeledger.sessionfacade.model.Filter;
import com.perry.tradeledger.sessionfacade.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@RestController
public class UserController {

    @Autowired
    private MongoTemplate mongoTemplate;


    @RequestMapping("user")
    public List<User> searchAllUsers() {
        return mongoTemplate.findAll(User.class);
    }


    @RequestMapping("/user/{id}")
    public User searchUser(@PathVariable String id) {
        User user = (User) mongoTemplate.findById(id, User.class);
        return user;
    }

    @GetMapping(value = "/user/search")
    public List<User> searchUsers(@RequestParam("filter") String filter)  {

        ObjectMapper mapper = new ObjectMapper();
        List<Filter> list = new ArrayList<>();
        try {
            list = mapper.readValue("[" + filter + "]", new TypeReference<List<Filter>>() {
            });
        } catch (Exception e) {
            throw new RuntimeException("Search filter is not a valid json", e);
        }


        ValidateFilter validateFilter = new ValidateFilter(list).invoke();
        boolean value = validateFilter.isValue();
        boolean range = validateFilter.isRange();


        Query query = new Query();


        for (Filter f : list) {
            if (f.getOperator().equals("eq")) {
                if (value) {
                    query.addCriteria(Criteria.where(f.getAttribute()).is(f.getValue()));
                }
                else if (range) {
                    query.addCriteria(Criteria.where(f.getAttribute()).gte(f.getRange().getFrom()));
                    query.addCriteria(Criteria.where(f.getAttribute()).lte(f.getRange().getTo()));
                }
            }
            if (f.getOperator().equals("gte")) {
                query.addCriteria(Criteria.where(f.getAttribute()).gte(f.getValue()));
            }
            if (f.getOperator().equals("lte")) {
                query.addCriteria(Criteria.where(f.getAttribute()).lte(f.getValue()));
            }
        }

        List<User> users = mongoTemplate.find(query, User.class);

        return users;
    }

    private class ValidateFilter {
        private List<Filter> list;
        private boolean value;
        private boolean range;

        public ValidateFilter(List<Filter> list) {
            this.list = list;
        }

        public boolean isValue() {
            return value;
        }

        public boolean isRange() {
            return range;
        }

        public ValidateFilter invoke() {
            value = false;
            range = false;
            boolean isGlte = false;

            for (Filter f : list) {
                if (!Arrays.asList("eq", "gte", "lte").contains(f.getOperator())) {
                    throw new RuntimeException("Unknown operators are not allowed.");
                }

                if (Arrays.asList("gte", "lte").contains(f.getOperator())) {
                    isGlte = true;
                }

                if (f.getValue() != null)  value = true;
                if (f.getRange() != null)  range = true;

                if (value && range) {
                    throw new RuntimeException("Both value and range are not allowed.");
                }

                if (isGlte && range) {
                    throw new RuntimeException("When operator is gte or lte then range is not allowed.");
                }
            }
            return this;
        }
    }
}
