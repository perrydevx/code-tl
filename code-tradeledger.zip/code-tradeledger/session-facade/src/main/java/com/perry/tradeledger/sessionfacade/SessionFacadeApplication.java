package com.perry.tradeledger.sessionfacade;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SessionFacadeApplication {

	public static void main(String[] args) {
		SpringApplication.run(SessionFacadeApplication.class, args);
	}

}
