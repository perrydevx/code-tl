package com.perry.tradeledger.sessionfacade.repository;

import com.perry.tradeledger.sessionfacade.model.User;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface UserRepository extends MongoRepository<User, String> {
    // not used
}
