package com.perry.tradeledger.sessionfacade.controller;

import com.perry.tradeledger.sessionfacade.model.Event;
import com.perry.tradeledger.sessionfacade.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class EventController {
    // TODO same implementation as UserController

    @Autowired
    private MongoTemplate mongoTemplate;

    @RequestMapping("/event/{id}")
    public Event searchEvent(@PathVariable String id) {
        Event event = (Event) mongoTemplate.findById(id, Event.class);
        return event;
    }

    @GetMapping(value = "/event/search")
    public List<User> searchEvents(@RequestParam("filter") String filter) {
        // TODO implement query filter
        Query query = new Query();

        List<User> users = mongoTemplate.find(query, User.class);

        return users;
    }

}
