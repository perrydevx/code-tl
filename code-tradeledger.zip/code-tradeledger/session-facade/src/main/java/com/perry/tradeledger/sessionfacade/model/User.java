package com.perry.tradeledger.sessionfacade.model;

import org.springframework.data.annotation.Id;

public class User {
    @Id
    String id;

    String user;
    String workstation;

    @Override
    public String toString() {
        return "User{" +
                "user='" + user + '\'' +
                ", workstation='" + workstation + '\'' +
                '}';
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getWorkstation() {
        return workstation;
    }

    public void setWorkstation(String workstation) {
        this.workstation = workstation;
    }
}
