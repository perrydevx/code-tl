package com.perry.tradeledger.sessionfacade.model;

import org.springframework.data.annotation.Id;

public class Event {
    @Id
    private String id;

    private String type;
    private Long time;
    private String user;
    private String ip;

    @Override
    public String toString() {
        return "Event{" +
                "type='" + type + '\'' +
                ", time=" + time +
                ", user='" + user + '\'' +
                ", ip='" + ip + '\'' +
                '}';
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Long getTime() {
        return time;
    }

    public void setTime(Long time) {
        this.time = time;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }
}
