package com.perry.tradeledger.sessionfacade.controller;

import com.perry.tradeledger.sessionfacade.model.User;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

import static org.junit.Assert.assertEquals;

@RunWith(SpringRunner.class)
@SpringBootTest
public class UserControllerTest {

    @Autowired
    private UserController controller;

    @Test()
    public void should_return_user_when_filter_is_valid() {
        String filter = "{\"attribute\": \"user\", \"operator\": \"eq\", \"value\": \"user4@sample.io\"}";
        List<User> list = controller.searchUsers(filter);

        assertEquals(list.size() ,1);
    }

    @Test(expected = RuntimeException.class)
    public void should_throw_exception_when_filter_operator_is_invalid() {
        String filter = "{\"attribute\": \"user\", \"operator\": \"eqt\", \"value\": \"user4@sample.io\"}";
        List<User> list = controller.searchUsers(filter);

        assertEquals(list.size() ,0);
    }

    @Test(expected = RuntimeException.class)
    public void should_throw_exception_when_both_value_and_range_has_value() {
        String filter = "{\"attribute\": \"user\", \"operator\": \"eq\", \"value\": \"user4@sample.io\"}, {\"attribute\": \"user\", \"operator\": \"eq\", \"range\": { \"from\": \"1\", \"to\": \"2\"}}";
        List<User> list = controller.searchUsers(filter);

        assertEquals(list.size() ,0);
    }

    @Test(expected = RuntimeException.class)
    public void should_throw_exception_when_operators_is_gte_or_lte_and_range_has_value() {
        String filter = "{\"attribute\": \"user\", \"operator\": \"lte\", \"range\": { \"from\": \"1\", \"to\": \"2\"}}";
        List<User> list = controller.searchUsers(filter);

        assertEquals(list.size() ,0);
    }


}