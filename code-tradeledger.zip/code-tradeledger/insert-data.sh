#!/usr/bin/env bash


echo "######################## Inserting sample data..."

mongoimport --port 27777 --db sample-tl --collection user --type json --drop --file sample-data/users.json --jsonArray
mongoimport --port 27777 --db sample-tl --collection event --type json --drop --file sample-data/events.json --jsonArray


echo "######################## Done inserting sample data!"


